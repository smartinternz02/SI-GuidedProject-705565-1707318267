
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String



def static "com.test.demo.AmazonPage.loginToAmazon"(
    	String username	
     , 	String password	) {
    (new com.test.demo.AmazonPage()).loginToAmazon(
        	username
         , 	password)
}
