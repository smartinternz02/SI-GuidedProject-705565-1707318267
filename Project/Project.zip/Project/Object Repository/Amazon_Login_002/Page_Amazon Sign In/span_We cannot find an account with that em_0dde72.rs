<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_We cannot find an account with that em_0dde72</name>
   <tag></tag>
   <elementGuidId>be98f443-ea8d-47cf-a490-6e5207e5784d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='auth-error-message-box']/div/div/ul/li/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-list-item</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>3b49490e-7b16-41eb-a5f9-5d52035d674f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-list-item</value>
      <webElementGuid>3a07337e-ec5e-4bc6-b8cd-3e95c1b98332</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            We cannot find an account with that email address
          </value>
      <webElementGuid>d25cfbc1-581c-48f9-a6fd-c348e0240aa9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;auth-error-message-box&quot;)/div[@class=&quot;a-box-inner a-alert-container&quot;]/div[@class=&quot;a-alert-content&quot;]/ul[@class=&quot;a-unordered-list a-nostyle a-vertical a-spacing-none&quot;]/li[1]/span[@class=&quot;a-list-item&quot;]</value>
      <webElementGuid>094eca08-f38d-49f8-9af5-fb5594551d1d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='auth-error-message-box']/div/div/ul/li/span</value>
      <webElementGuid>ccf57498-6874-4e43-90ef-77d92b8f4949</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span</value>
      <webElementGuid>313d71ba-e4bd-49b0-b1ce-2b377164cb1f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
            We cannot find an account with that email address
          ' or . = '
            We cannot find an account with that email address
          ')]</value>
      <webElementGuid>04032fba-236c-4194-87e5-220656f94f86</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
